import { Navigation } from './modules/navigation.js';

document.addEventListener('DOMContentLoaded', () => {
    new Navigation();
});
